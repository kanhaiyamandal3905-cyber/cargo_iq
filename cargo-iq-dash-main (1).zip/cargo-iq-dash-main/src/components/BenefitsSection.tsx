import { motion } from "framer-motion";
import { Clock, TrendingUp, Shield, Rocket } from "lucide-react";

const benefits = [
  { icon: Clock, value: "80%", label: "Time Saved", desc: "Reduce research and calculation time drastically." },
  { icon: TrendingUp, value: "3×", label: "Better Decisions", desc: "Data-driven insights for smarter trade choices." },
  { icon: Shield, value: "100%", label: "Transparency", desc: "Full cost breakdowns with zero hidden fees." },
  { icon: Rocket, value: "10×", label: "SME Growth", desc: "Empowering small businesses to trade globally." },
];

const BenefitsSection = () => (
  <section id="benefits" className="py-24 relative">
    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-secondary/[0.03] to-transparent" />
    <div className="container mx-auto px-6 relative">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <p className="text-sm font-medium text-primary mb-3 uppercase tracking-widest">Impact</p>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
          Real Results, <span className="gradient-text">Real Impact</span>
        </h2>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {benefits.map((b, i) => (
          <motion.div
            key={b.label}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass-card rounded-xl p-6 text-center group hover:border-primary/30 transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
              <b.icon className="w-6 h-6 text-primary" />
            </div>
            <p className="text-3xl font-bold gradient-text mb-1">{b.value}</p>
            <p className="font-semibold text-sm mb-1">{b.label}</p>
            <p className="text-xs text-muted-foreground">{b.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default BenefitsSection;
