import { motion } from "framer-motion";
import { AlertTriangle, Layers, Globe, HelpCircle } from "lucide-react";

const problems = [
  { icon: AlertTriangle, title: "Complex Calculations", desc: "Tariff and shipping cost calculations are tangled in red tape and outdated systems." },
  { icon: Layers, title: "No Cost Transparency", desc: "Hidden fees and opaque breakdowns make it impossible to budget accurately." },
  { icon: Globe, title: "Hard to Compare", desc: "Comparing costs across countries and carriers is a manual nightmare." },
  { icon: HelpCircle, title: "Fragmented Tools", desc: "Businesses juggle 5+ tools just to manage one international shipment." },
];

const ProblemSection = () => (
  <section className="py-24 relative">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <p className="text-sm font-medium text-primary mb-3 uppercase tracking-widest">The Problem</p>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
          Global Trade Is <span className="gradient-text">Broken</span>
        </h2>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Businesses waste thousands of hours and dollars navigating fragmented, confusing systems.
        </p>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {problems.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass-card rounded-xl p-6 hover:border-primary/30 transition-all group"
          >
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
              <p.icon className="w-5 h-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">{p.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{p.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ProblemSection;
