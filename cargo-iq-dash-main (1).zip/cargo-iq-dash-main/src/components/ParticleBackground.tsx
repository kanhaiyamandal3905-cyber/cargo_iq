import { useEffect, useRef } from "react";

const PARTICLE_IDS = Array.from({ length: 30 }, (_, i) => `particle-${i}-static`);

export function ParticleBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {PARTICLE_IDS.map((id, i) => (
        <div key={id} className="particle"
          style={{
            left: `${((i * 37) % 100)}%`,
            top: `${((i * 53) % 100)}%`,
            width: `${(i % 4) + 2}px`,
            height: `${(i % 4) + 2}px`,
            background: i % 3 === 0 ? "hsla(var(--primary), 0.6)" : i % 3 === 1 ? "hsla(var(--secondary), 0.6)" : "rgba(59, 130, 246, 0.6)",
            boxShadow: i % 3 === 0 ? "0 0 10px hsla(var(--primary), 0.8)" : i % 3 === 1 ? "0 0 10px hsla(var(--secondary), 0.8)" : "0 0 10px rgba(59, 130, 246, 0.8)",
            animationDuration: `${(i % 20) + 10}s`,
            animationDelay: `${(i % 10)}s`,
          }}
        />
      ))}
    </div>
  );
}

export function CursorGlow() {
  const cursorRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (cursorRef.current) {
        cursorRef.current.style.left = `${e.clientX}px`;
        cursorRef.current.style.top = `${e.clientY}px`;
      }
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  return <div ref={cursorRef} className="cursor-glow" style={{ width: 40, height: 40 }} />;
}
