import { motion } from "framer-motion";
import { Ship, Calculator, Route, MapPin, Bot } from "lucide-react";

const features = [
  { icon: Ship, title: "Shipping Cost Comparison", desc: "Compare rates across carriers, routes, and shipping modes in seconds." },
  { icon: Calculator, title: "Tariff & Duty Calculator", desc: "Instantly calculate tariffs, duties, and taxes for any destination." },
  { icon: Route, title: "Route Optimization", desc: "Find the fastest and most cost-effective shipping routes globally." },
  { icon: MapPin, title: "Real-Time Tracking", desc: "Track shipments across the globe with live status updates." },
  { icon: Bot, title: "AI Trade Assistant", desc: "Get AI-driven insights, recommendations, and answers to trade questions." },
];

const FeaturesSection = () => (
  <section id="features" className="py-24">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <p className="text-sm font-medium text-primary mb-3 uppercase tracking-widest">Features</p>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
          Everything You Need for <span className="gradient-text">Global Trade</span>
        </h2>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
        {features.map((f, i) => (
          <motion.div
            key={f.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="gradient-border rounded-2xl p-7 group hover:-translate-y-1 transition-transform duration-300"
          >
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
              <f.icon className="w-6 h-6 text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default FeaturesSection;
