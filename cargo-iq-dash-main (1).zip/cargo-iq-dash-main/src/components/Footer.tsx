import { Ship, Twitter, Linkedin, Github } from "lucide-react";

const Footer = () => (
  <footer className="border-t border-border/50 py-12">
    <div className="container mx-auto px-6">
      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <Ship className="w-5 h-5 text-primary" />
          <span className="font-bold">Cargo <span className="gradient-text">IQ</span></span>
        </div>

        <div className="flex items-center gap-6">
          {[Twitter, Linkedin, Github].map((Icon, i) => (
            <a
              key={i}
              href="#"
              className="w-9 h-9 rounded-lg glass-card flex items-center justify-center text-muted-foreground hover:text-foreground hover:border-primary/30 transition-all"
            >
              <Icon className="w-4 h-4" />
            </a>
          ))}
        </div>

        <p className="text-xs text-muted-foreground">
          © 2026 Cargo IQ. All rights reserved.
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
