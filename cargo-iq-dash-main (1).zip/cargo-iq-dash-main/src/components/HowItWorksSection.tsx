import { motion } from "framer-motion";
import { Package, PieChart, CheckCircle } from "lucide-react";

const steps = [
  { icon: Package, step: "01", title: "Enter Product & Destination", desc: "Input your product details, origin, and destination country." },
  { icon: PieChart, step: "02", title: "Get Cost Breakdown", desc: "Receive a transparent breakdown of shipping, tariffs, and duties." },
  { icon: CheckCircle, step: "03", title: "Compare & Choose", desc: "Compare options across carriers and routes. Pick the best one." },
];

const HowItWorksSection = () => (
  <section id="how-it-works" className="py-24">
    <div className="container mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <p className="text-sm font-medium text-primary mb-3 uppercase tracking-widest">How It Works</p>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
          Three Steps to <span className="gradient-text">Smarter Trade</span>
        </h2>
      </motion.div>

      <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
        {steps.map((s, i) => (
          <motion.div
            key={s.step}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.15 }}
            className="relative text-center"
          >
            {i < steps.length - 1 && (
              <div className="hidden md:block absolute top-12 left-[60%] w-[80%] h-px bg-gradient-to-r from-primary/30 to-transparent" />
            )}
            <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-5 relative">
              <s.icon className="w-7 h-7 text-primary" />
              <span className="absolute -top-2 -right-2 text-[10px] font-bold bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center">
                {s.step}
              </span>
            </div>
            <h3 className="font-semibold mb-2">{s.title}</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default HowItWorksSection;
