import { motion } from "framer-motion";
import { Globe, BrainCircuit, Link2, Store } from "lucide-react";

const visions = [
  { icon: Globe, title: "Global Expansion", desc: "Covering every trade corridor and emerging market worldwide." },
  { icon: BrainCircuit, title: "AI Predictions", desc: "Forecasting costs, demand, and disruptions before they happen." },
  { icon: Link2, title: "Blockchain Integration", desc: "Immutable records for supply chain transparency and trust." },
  { icon: Store, title: "B2B Marketplace", desc: "Connecting importers, exporters, and logistics providers seamlessly." },
];

const VisionSection = () => (
  <section id="vision" className="py-24 relative">
    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/[0.03] to-transparent" />
    <div className="container mx-auto px-6 relative">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <p className="text-sm font-medium text-primary mb-3 uppercase tracking-widest">Vision</p>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
          The Future of <span className="gradient-text">Trade</span>
        </h2>
        <p className="text-muted-foreground max-w-xl mx-auto">
          We're building toward a world where global trade is as simple as a few clicks.
        </p>
      </motion.div>

      <div className="grid sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
        {visions.map((v, i) => (
          <motion.div
            key={v.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass-card rounded-xl p-6 flex gap-4 items-start hover:border-primary/30 transition-all"
          >
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <v.icon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-semibold mb-1">{v.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default VisionSection;
