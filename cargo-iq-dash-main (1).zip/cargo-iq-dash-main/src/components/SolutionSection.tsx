import { motion } from "framer-motion";
import { Brain, BarChart3, Eye, Globe2, Lightbulb } from "lucide-react";

const solutions = [
  { icon: Globe2, label: "All-in-One Platform" },
  { icon: Brain, label: "AI-Powered Calculations" },
  { icon: Eye, label: "Transparent Breakdown" },
  { icon: BarChart3, label: "Global Comparison" },
  { icon: Lightbulb, label: "Smart Recommendations" },
];

const SolutionSection = () => (
  <section className="py-24 relative">
    <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/[0.03] to-transparent" />
    <div className="container mx-auto px-6 relative">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <p className="text-sm font-medium text-primary mb-3 uppercase tracking-widest">The Solution</p>
        <h2 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
          One Platform. <span className="gradient-text">Zero Confusion.</span>
        </h2>
        <p className="text-muted-foreground max-w-xl mx-auto">
          Cargo IQ replaces fragmented tools with a single, intelligent platform for global trade.
        </p>
      </motion.div>

      <div className="flex flex-wrap justify-center gap-4">
        {solutions.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="glass-card rounded-xl px-6 py-4 flex items-center gap-3 hover:border-primary/30 transition-all cursor-default"
          >
            <s.icon className="w-5 h-5 text-primary flex-shrink-0" />
            <span className="text-sm font-medium">{s.label}</span>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default SolutionSection;
