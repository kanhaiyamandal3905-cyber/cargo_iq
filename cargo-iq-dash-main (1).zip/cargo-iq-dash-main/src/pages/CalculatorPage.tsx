import { useState } from "react";
import { COUNTRIES, CURRENCIES, MOCK_PRODUCTS, TAX_RULES, convertPrice, formatPrice } from "@/data/mockData";

interface Breakdown {
  basePrice: number; shipping: number; importDuty: number;
  gstVat: number; customsClearance: number; insurance: number;
  handlingCharges: number; totalLandingCost: number;
}

const CalculatorPage = () => {
  const [selectedProduct, setSelectedProduct] = useState(MOCK_PRODUCTS[0]);
  const [sourceCountry, setSourceCountry] = useState("USA");
  const [destCountry, setDestCountry] = useState("India");
  const [outputCurrency, setOutputCurrency] = useState("INR");
  const [breakdown, setBreakdown] = useState<Breakdown | null>(null);
  const [calculating, setCalculating] = useState(false);

  const getShippingCost = (from: string, to: string): number => {
    const asia = ["India", "China", "Japan", "Singapore", "South Korea"];
    const eu = ["Germany", "UK", "France"];
    const fromAsia = asia.includes(from); const toAsia = asia.includes(to);
    const fromEU = eu.includes(from); const toEU = eu.includes(to);
    if ((fromAsia && toAsia) || (fromEU && toEU)) return 200;
    if ((fromAsia && toEU) || (fromEU && toAsia)) return 600;
    return 400;
  };

  const calculate = () => {
    setCalculating(true);
    setTimeout(() => {
      const sourcePrice = selectedProduct.countryPrices.find((cp) => cp.country === sourceCountry) ?? selectedProduct.countryPrices[0];
      const basePriceUSD = sourcePrice.usdPrice;
      const rules = TAX_RULES[selectedProduct.category] ?? TAX_RULES.default;
      const shipping = getShippingCost(sourceCountry, destCountry);
      const importDuty = basePriceUSD * rules.duty;
      const gstVat = (basePriceUSD + importDuty) * rules.gst;
      const customsClearance = 150;
      const insurance = basePriceUSD * rules.insurance;
      const handlingCharges = rules.handling;
      const total = basePriceUSD + shipping + importDuty + gstVat + customsClearance + insurance + handlingCharges;
      setBreakdown({ basePrice: basePriceUSD, shipping, importDuty, gstVat, customsClearance, insurance, handlingCharges, totalLandingCost: total });
      setCalculating(false);
    }, 600);
  };

  const fmt = (usd: number) => formatPrice(convertPrice(usd, outputCurrency), outputCurrency);

  const breakdownRows = breakdown ? [
    { label: "Product Base Price", value: breakdown.basePrice, icon: "📦", color: "text-foreground" },
    { label: "Shipping & Logistics", value: breakdown.shipping, icon: "🚚", color: "text-blue-400" },
    { label: "Import Duty", value: breakdown.importDuty, icon: "🏦", color: "text-orange-400" },
    { label: "GST / VAT", value: breakdown.gstVat, icon: "💳", color: "text-yellow-400" },
    { label: "Customs Clearance", value: breakdown.customsClearance, icon: "🔖", color: "text-purple-400" },
    { label: "Insurance", value: breakdown.insurance, icon: "🛡️", color: "text-primary" },
    { label: "Handling Charges", value: breakdown.handlingCharges, icon: "🧰", color: "text-muted-foreground" },
  ] : [];

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-foreground mb-2">Import Cost <span className="neon-text">Calculator</span></h1>
          <p className="text-muted-foreground">Get a complete breakdown of your total landing cost including all duties and taxes</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Configuration */}
          <div className="space-y-4">
            <div className="glass-card p-5">
              <label htmlFor="calc-product" className="text-xs text-primary font-medium uppercase tracking-wider mb-3 block">Select Product</label>
              <select id="calc-product" value={selectedProduct.id}
                onChange={(e) => { const p = MOCK_PRODUCTS.find((p) => p.id === Number.parseInt(e.target.value)); if (p) setSelectedProduct(p); }}
                className="w-full bg-card border border-border text-foreground px-3 py-2.5 rounded-lg text-sm outline-none focus:border-primary/50"
              >
                {MOCK_PRODUCTS.map((p) => (<option key={p.id} value={p.id}>{p.name} ({p.brand})</option>))}
              </select>
              {selectedProduct && (
                <div className="mt-3 p-3 bg-white/[0.03] rounded-lg">
                  <div className="text-xs text-muted-foreground">{selectedProduct.specifications}</div>
                  <div className="flex gap-3 mt-2">
                    <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded">{selectedProduct.category}</span>
                    <span className="text-xs bg-secondary/20 text-secondary px-2 py-0.5 rounded">{selectedProduct.brand}</span>
                  </div>
                </div>
              )}
            </div>

            <div className="glass-card p-5">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label htmlFor="calc-source" className="text-xs text-primary font-medium uppercase tracking-wider mb-2 block">Source Country</label>
                  <select id="calc-source" value={sourceCountry} onChange={(e) => setSourceCountry(e.target.value)}
                    className="w-full bg-card border border-border text-foreground px-3 py-2.5 rounded-lg text-sm outline-none focus:border-primary/50"
                  >
                    {COUNTRIES.map((c) => (<option key={c.name} value={c.name}>{c.flag} {c.name}</option>))}
                  </select>
                </div>
                <div>
                  <label htmlFor="calc-dest" className="text-xs text-secondary font-medium uppercase tracking-wider mb-2 block">Destination Country</label>
                  <select id="calc-dest" value={destCountry} onChange={(e) => setDestCountry(e.target.value)}
                    className="w-full bg-card border border-border text-foreground px-3 py-2.5 rounded-lg text-sm outline-none focus:border-primary/50"
                  >
                    {COUNTRIES.map((c) => (<option key={c.name} value={c.name}>{c.flag} {c.name}</option>))}
                  </select>
                </div>
              </div>
            </div>

            <div className="glass-card p-5">
              <label htmlFor="calc-currency" className="text-xs text-muted-foreground font-medium uppercase tracking-wider mb-2 block">Output Currency</label>
              <select id="calc-currency" value={outputCurrency} onChange={(e) => setOutputCurrency(e.target.value)}
                className="w-full bg-card border border-border text-foreground px-3 py-2.5 rounded-lg text-sm outline-none focus:border-primary/50 mb-4"
              >
                {Object.entries(CURRENCIES).map(([code, info]) => (<option key={code} value={code}>{code} ({info.symbol}) - {info.name}</option>))}
              </select>
              <button onClick={calculate} disabled={calculating}
                className="w-full glow-btn py-3.5 rounded-xl font-semibold text-white text-sm disabled:opacity-60 flex items-center justify-center gap-2"
              >
                {calculating ? (
                  <><div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />Calculating...</>
                ) : (<>⚡ Calculate Total Landing Cost</>)}
              </button>
            </div>

            <div className="glass-card p-4">
              <div className="text-xs text-muted-foreground font-medium mb-3">Tax Structure: {selectedProduct.category}</div>
              <div className="space-y-2">
                {(() => {
                  const rules = TAX_RULES[selectedProduct.category] ?? TAX_RULES.default;
                  return [
                    { label: "Import Duty", value: `${(rules.duty * 100).toFixed(0)}%` },
                    { label: "GST / VAT", value: `${(rules.gst * 100).toFixed(0)}%` },
                    { label: "Insurance", value: `${(rules.insurance * 100).toFixed(1)}%` },
                    { label: "Handling", value: `$${rules.handling}` },
                  ].map((row) => (
                    <div key={row.label} className="flex justify-between text-xs">
                      <span className="text-muted-foreground">{row.label}</span>
                      <span className="text-primary font-medium">{row.value}</span>
                    </div>
                  ));
                })()}
              </div>
            </div>
          </div>

          {/* Results */}
          <div>
            {breakdown ? (
              <div className="glass-card p-6 neon-border fade-in-up">
                <h3 className="text-lg font-bold text-foreground mb-5">Cost Breakdown</h3>
                <div className="space-y-3 mb-6">
                  {breakdownRows.map((row) => (
                    <div key={row.label} className="flex items-center justify-between py-2.5 border-b border-border/50">
                      <div className="flex items-center gap-2">
                        <span>{row.icon}</span>
                        <span className="text-sm text-muted-foreground">{row.label}</span>
                      </div>
                      <div className="text-right">
                        <div className={`text-sm font-semibold ${row.color}`}>{fmt(row.value)}</div>
                        <div className="text-xs text-muted-foreground">${row.value.toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="p-5 rounded-xl text-center" style={{ background: "linear-gradient(135deg, hsla(var(--primary), 0.1), hsla(var(--secondary), 0.1))", border: "1px solid hsla(var(--primary), 0.3)" }}>
                  <div className="text-sm text-muted-foreground mb-1">Total Landing Cost</div>
                  <div className="text-4xl font-black neon-text">{fmt(breakdown.totalLandingCost)}</div>
                  <div className="text-sm text-muted-foreground mt-1">${breakdown.totalLandingCost.toFixed(2)} USD</div>
                </div>

                <div className="flex items-center justify-center gap-3 mt-5 py-3 bg-white/[0.03] rounded-xl">
                  <span className="text-sm text-muted-foreground">{COUNTRIES.find((c) => c.name === sourceCountry)?.flag} {sourceCountry}</span>
                  <span className="text-primary">→→→</span>
                  <span className="text-sm text-muted-foreground">{COUNTRIES.find((c) => c.name === destCountry)?.flag} {destCountry}</span>
                </div>

                <div className="mt-5">
                  <div className="text-xs text-muted-foreground mb-2">Cost Distribution</div>
                  <div className="flex rounded-full overflow-hidden h-3">
                    {breakdownRows.map((row, i) => {
                      const pct = (row.value / breakdown.totalLandingCost) * 100;
                      const colors = ["#3b82f6", "#06b6d4", "#f97316", "#eab308", "#8b5cf6", "#06b6d4", "#94a3b8"];
                      return <div key={row.label} style={{ width: `${pct}%`, background: colors[i] }} title={row.label} />;
                    })}
                  </div>
                  <div className="flex flex-wrap gap-x-3 gap-y-1 mt-2">
                    {breakdownRows.map((row, i) => {
                      const colors = ["bg-blue-500", "bg-cyan-500", "bg-orange-500", "bg-yellow-500", "bg-purple-500", "bg-cyan-400", "bg-slate-400"];
                      return (
                        <div key={row.label} className="flex items-center gap-1">
                          <div className={`w-2 h-2 rounded-full ${colors[i]}`} />
                          <span className="text-xs text-muted-foreground">{row.label.split(" ")[0]}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ) : (
              <div className="glass-card p-12 text-center h-full flex flex-col items-center justify-center">
                <div className="text-6xl mb-4">💹</div>
                <h3 className="text-xl font-bold text-foreground mb-2">Ready to Calculate</h3>
                <p className="text-muted-foreground text-sm max-w-xs">Select a product, choose source and destination countries, then click Calculate.</p>
                <div className="mt-6 grid grid-cols-2 gap-3 text-center w-full max-w-xs">
                  {["Import Duty", "GST/VAT", "Shipping", "Insurance", "Customs", "Handling"].map((t) => (
                    <div key={t} className="bg-white/[0.03] border border-border rounded-lg py-2 text-xs text-muted-foreground">{t}</div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalculatorPage;
