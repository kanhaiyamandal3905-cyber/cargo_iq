import { useState } from "react";
import { CATEGORIES, MOCK_LISTINGS } from "@/data/mockData";

const STAR_INDICES = [0, 1, 2, 3, 4];

const MarketplacePage = () => {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [sortBy, setSortBy] = useState("featured");
  const [selectedListing, setSelectedListing] = useState<(typeof MOCK_LISTINGS)[0] | null>(null);
  const [showListForm, setShowListForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const categories = ["All", ...CATEGORIES.map((c) => c.name)];
  const filtered = MOCK_LISTINGS
    .filter((l) => selectedCategory === "All" || l.category === selectedCategory)
    .filter((l) => searchQuery === "" || l.productName.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => {
      if (sortBy === "price-asc") return a.priceUSD - b.priceUSD;
      if (sortBy === "price-desc") return b.priceUSD - a.priceUSD;
      if (sortBy === "rating") return b.rating - a.rating;
      return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
    });

  const mockReviews = [
    { reviewer: "Ali Hassan", rating: 5, comment: "Excellent product, exactly as described. Fast shipping!", date: "2 days ago" },
    { reviewer: "Priya Sharma", rating: 4, comment: "Good quality, minor packaging damage but product is perfect.", date: "1 week ago" },
    { reviewer: "James Wilson", rating: 5, comment: "Best deal globally! Highly recommend this seller.", date: "2 weeks ago" },
  ];

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-black text-foreground mb-1">Global <span className="neon-text">Marketplace</span></h1>
            <p className="text-muted-foreground">Connect with verified sellers and importers worldwide</p>
          </div>
          <button onClick={() => setShowListForm(true)} className="glow-btn px-5 py-2.5 rounded-lg font-semibold text-white text-sm">+ List a Product</button>
        </div>

        {/* Filters */}
        <div className="glass-card p-4 mb-6">
          <div className="flex flex-wrap gap-3 items-center">
            <input type="text" placeholder="Search listings..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-1 min-w-48 bg-white/5 border border-border rounded-lg px-4 py-2 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary/50"
            />
            <div className="flex flex-wrap gap-2">
              {categories.slice(0, 6).map((cat) => (
                <button key={cat} onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 text-xs rounded-full border transition-all ${selectedCategory === cat ? "bg-primary/20 border-primary/50 text-primary" : "border-border text-muted-foreground hover:border-border/80"}`}
                >
                  {cat === "All" ? "All" : cat.split(" ")[0]}
                </button>
              ))}
            </div>
            <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}
              className="bg-card border border-border text-foreground px-3 py-2 rounded-lg text-xs outline-none"
            >
              <option value="featured">Featured First</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((listing) => (
            <button key={listing.id} className="glass-card p-4 cursor-pointer group transition-all duration-300 hover:scale-[1.02] text-left"
              onClick={() => setSelectedListing(listing)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{listing.flag}</span>
                  <div>
                    <div className="text-xs text-muted-foreground">{listing.country}</div>
                    <div className="flex gap-1 mt-0.5">
                      {listing.isFeatured && <span className="text-xs bg-yellow-500/20 text-yellow-400 px-1.5 py-0.5 rounded font-medium">Featured</span>}
                      {listing.isNew && <span className="text-xs bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded font-medium">New</span>}
                    </div>
                  </div>
                </div>
                <span className="text-lg">{CATEGORIES.find((c) => c.name === listing.category)?.icon ?? "📦"}</span>
              </div>
              <h3 className="font-semibold text-foreground text-sm mb-1 group-hover:text-primary transition-colors line-clamp-2 leading-snug">{listing.productName}</h3>
              <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{listing.description}</p>
              <div className="text-xs text-muted-foreground mb-3">by {listing.sellerName}</div>
              <div className="flex items-center justify-between pt-3 border-t border-border/50">
                <div className="text-lg font-bold text-primary">${listing.priceUSD.toLocaleString()}</div>
                <div className="flex items-center gap-1">
                  {STAR_INDICES.map((i) => (
                    <span key={`star-${listing.id}-${i}`} className={`text-xs ${i < Math.floor(listing.rating) ? "text-yellow-400" : "text-muted"}`}>★</span>
                  ))}
                  <span className="text-xs text-muted-foreground ml-1">({listing.reviews})</span>
                </div>
              </div>
            </button>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16 text-muted-foreground">
            <div className="text-5xl mb-4">🔍</div>
            <p>No listings found. Try adjusting your filters.</p>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selectedListing && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setSelectedListing(null)}>
          <div className="glass-card neon-border max-w-lg w-full p-6 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-2">
                <span className="text-3xl">{selectedListing.flag}</span>
                <div>
                  <div className="text-sm text-muted-foreground">{selectedListing.country}</div>
                  <div className="text-xs text-primary">{selectedListing.category}</div>
                </div>
              </div>
              <button onClick={() => setSelectedListing(null)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">{selectedListing.productName}</h2>
            <p className="text-sm text-muted-foreground mb-4">{selectedListing.description}</p>
            <div className="flex items-center justify-between mb-4 p-4 bg-white/[0.03] rounded-xl">
              <div>
                <div className="text-xs text-muted-foreground">Listed Price</div>
                <div className="text-2xl font-black text-primary">${selectedListing.priceUSD.toLocaleString()}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground">Seller</div>
                <div className="text-sm font-medium text-foreground">{selectedListing.sellerName}</div>
              </div>
            </div>
            <div className="flex items-center gap-1 mb-6">
              {STAR_INDICES.map((i) => (
                <span key={`star-d-${i}`} className={`${i < Math.floor(selectedListing.rating) ? "text-yellow-400" : "text-muted"}`}>★</span>
              ))}
              <span className="text-sm text-muted-foreground ml-1">{selectedListing.rating} ({selectedListing.reviews} reviews)</span>
            </div>
            <h3 className="font-semibold text-foreground mb-3">Recent Reviews</h3>
            <div className="space-y-3 mb-6">
              {mockReviews.map((r) => (
                <div key={r.reviewer} className="p-3 bg-white/[0.03] rounded-lg">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-foreground">{r.reviewer}</span>
                    <div className="flex items-center gap-1">
                      {Array.from({ length: r.rating }).map((_, j) => (<span key={`rs-${r.reviewer}-${j}`} className="text-xs text-yellow-400">★</span>))}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">{r.comment}</p>
                  <div className="text-xs text-muted mt-1">{r.date}</div>
                </div>
              ))}
            </div>
            <div className="flex gap-3">
              <button className="flex-1 glow-btn py-3 rounded-xl text-white font-semibold text-sm">Contact Seller</button>
              <button className="flex-1 py-3 rounded-xl font-semibold text-sm border border-border text-muted-foreground hover:border-primary/40 hover:text-primary transition-all">Add to Favorites</button>
            </div>
          </div>
        </div>
      )}

      {/* List Product Modal */}
      {showListForm && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4" onClick={() => setShowListForm(false)}>
          <div className="glass-card neon-border max-w-md w-full p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-foreground">List a Product</h2>
              <button onClick={() => setShowListForm(false)} className="text-muted-foreground hover:text-foreground">✕</button>
            </div>
            <div className="space-y-3">
              {[
                { label: "Product Name", id: "f-name", placeholder: "e.g. iPhone 15 Pro Max 256GB" },
                { label: "Price (USD)", id: "f-price", placeholder: "e.g. 1150" },
                { label: "Description", id: "f-desc", placeholder: "Describe your product..." },
              ].map((field) => (
                <div key={field.label}>
                  <label htmlFor={field.id} className="text-xs text-muted-foreground mb-1 block">{field.label}</label>
                  {field.label === "Description" ? (
                    <textarea id={field.id} rows={3} placeholder={field.placeholder} className="w-full bg-white/5 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary/50" />
                  ) : (
                    <input id={field.id} type="text" placeholder={field.placeholder} className="w-full bg-white/5 border border-border rounded-lg px-3 py-2 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary/50" />
                  )}
                </div>
              ))}
              <select className="w-full bg-card border border-border text-foreground px-3 py-2 rounded-lg text-sm outline-none">
                <option value="">Select Category</option>
                {CATEGORIES.map((c) => (<option key={c.name} value={c.name}>{c.name}</option>))}
              </select>
            </div>
            <button onClick={() => setShowListForm(false)} className="w-full glow-btn py-3 rounded-xl text-white font-semibold text-sm mt-5">Submit Listing</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketplacePage;
