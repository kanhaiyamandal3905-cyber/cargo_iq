import { useState } from "react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { COST_BREAKDOWNS, type CountryComparison, DEMAND_INDEX_DATA, LITHIUM_BATTERY_COMPARISONS, PRICE_TREND_DATA, SHIPPING_CARRIERS } from "@/data/analysisData";

const SEARCH_PRODUCTS = ["Lithium Batteries", "Steel Coils", "Solar Panels", "Semiconductors", "Copper Wire", "Pharmaceutical APIs", "Textile Yarn", "Auto Components"];
const SOURCE_COUNTRIES = ["China", "Germany", "USA", "Japan", "India", "South Korea"];
const CITIES: Record<string, string[]> = {
  China: ["Shanghai", "Shenzhen", "Beijing", "Guangzhou"],
  Germany: ["Hamburg", "Frankfurt", "Munich", "Berlin"],
  USA: ["Los Angeles", "New York", "Houston", "Chicago"],
  Japan: ["Tokyo", "Osaka", "Yokohama", "Nagoya"],
  India: ["Mumbai", "Delhi", "Chennai", "Kolkata"],
  "South Korea": ["Seoul", "Busan", "Incheon", "Daejeon"],
};

function DemandBadge({ demand }: { demand: "High" | "Medium" | "Low" }) {
  const styles = { High: "bg-green-500/20 text-green-400 border-green-500/30", Medium: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30", Low: "bg-red-500/20 text-red-400 border-red-500/30" };
  return <span className={`px-2 py-0.5 rounded text-xs font-medium border ${styles[demand]}`}>{demand}</span>;
}

function StarRating({ rating }: { rating: number }) {
  return <span className="text-yellow-400 text-sm">{"★".repeat(Math.floor(rating))}{rating % 1 >= 0.5 ? "½" : ""} <span className="text-muted-foreground">{rating}</span></span>;
}

const AnalysisPage = () => {
  const [searchQuery, setSearchQuery] = useState("Lithium Batteries");
  const [selectedCountry, setSelectedCountry] = useState("China");
  const [selectedCity, setSelectedCity] = useState("Shanghai");
  const [analyzed, setAnalyzed] = useState(true);
  const [selectedRow, setSelectedRow] = useState<CountryComparison>(LITHIUM_BATTERY_COMPARISONS[6]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const costBreakdown = COST_BREAKDOWNS[selectedRow.country] ?? COST_BREAKDOWNS.China;
  const handleAnalyze = () => { setAnalyzed(true); setSelectedRow(LITHIUM_BATTERY_COMPARISONS[6]); };
  const bestCountry = LITHIUM_BATTERY_COMPARISONS.find((c) => c.isBest);

  return (
    <div className="min-h-screen pt-20 pb-16 px-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Search */}
        <div className="glass-card p-4">
          <div className="flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-64">
              <input type="text" value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setShowSuggestions(true); }}
                onFocus={() => setShowSuggestions(true)} onBlur={() => setTimeout(() => setShowSuggestions(false), 150)}
                placeholder="Enter product name (e.g. Lithium Batteries, Steel Coils...)"
                className="w-full bg-white/5 border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary/50"
              />
              {showSuggestions && (
                <div className="absolute top-full mt-1 left-0 right-0 z-50 glass-card border border-border rounded-lg overflow-hidden">
                  {SEARCH_PRODUCTS.filter((p) => p.toLowerCase().includes(searchQuery.toLowerCase())).map((p) => (
                    <button key={p} onClick={() => { setSearchQuery(p); setShowSuggestions(false); }}
                      className="w-full text-left px-4 py-2 text-sm text-muted-foreground hover:bg-primary/10 hover:text-primary transition-colors"
                    >{p}</button>
                  ))}
                </div>
              )}
            </div>
            <select value={selectedCountry} onChange={(e) => { setSelectedCountry(e.target.value); setSelectedCity(CITIES[e.target.value]?.[0] ?? ""); }}
              className="bg-white/5 border border-border rounded-lg px-3 py-2.5 text-sm text-foreground focus:outline-none focus:border-primary/50"
            >
              {SOURCE_COUNTRIES.map((c) => (<option key={c} value={c} className="bg-card">{c}</option>))}
            </select>
            <select value={selectedCity} onChange={(e) => setSelectedCity(e.target.value)}
              className="bg-white/5 border border-border rounded-lg px-3 py-2.5 text-sm text-foreground focus:outline-none focus:border-primary/50"
            >
              {(CITIES[selectedCountry] ?? []).map((c) => (<option key={c} value={c} className="bg-card">{c}</option>))}
            </select>
            <button onClick={handleAnalyze} className="px-6 py-2.5 rounded-lg text-sm font-semibold bg-green-500 hover:bg-green-400 text-black transition-all duration-200 shadow-lg shadow-green-500/20">Analyze</button>
          </div>
        </div>

        {analyzed && (
          <>
            {/* Breadcrumb */}
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="px-3 py-1 bg-white/10 rounded-full text-sm text-foreground font-medium">{searchQuery}</span>
                <span className="px-2 py-0.5 bg-green-500/20 text-green-400 text-xs rounded border border-green-500/30">Germany</span>
                <span className="px-2 py-0.5 bg-primary/20 text-primary text-xs rounded border border-primary/30">HS: 850710</span>
              </div>
              <div className="text-sm text-muted-foreground">Base Price: <span className="text-foreground font-semibold">$1,250</span> per unit</div>
            </div>

            {/* KPIs */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: "💵", label: "Total Landed Cost", value: "$2,754", color: "text-foreground" },
                { icon: "📈", label: "Market Demand", value: "High", color: "text-teal-400" },
                { icon: "📦", label: "Products Tracked", value: "8", color: "text-orange-400" },
                { icon: "📅", label: "Est. Delivery", value: "19 days", color: "text-purple-400" },
              ].map((kpi) => (
                <div key={kpi.label} className="glass-card p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center text-lg">{kpi.icon}</div>
                    <span className="text-xs text-muted-foreground">{kpi.label}</span>
                  </div>
                  <div className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</div>
                </div>
              ))}
            </div>

            {/* Main */}
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Country Table */}
              <div className="lg:col-span-2 glass-card p-5">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-base font-semibold text-foreground">Country Comparison</h2>
                  {bestCountry && <span className="px-3 py-1 bg-green-500/20 text-green-400 text-xs rounded-full border border-green-500/30 font-medium">🏆 Best {bestCountry.country}</span>}
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border/50 text-muted-foreground text-xs">
                        <th className="text-left pb-3 pr-4">Country</th>
                        <th className="text-right pb-3 px-3">Duty</th>
                        <th className="text-right pb-3 px-3">Tax</th>
                        <th className="text-right pb-3 px-3">Shipping</th>
                        <th className="text-right pb-3 px-3">Total</th>
                        <th className="text-center pb-3 pl-3">Demand</th>
                      </tr>
                    </thead>
                    <tbody>
                      {LITHIUM_BATTERY_COMPARISONS.map((row) => (
                        <tr key={row.country} onClick={() => setSelectedRow(row)}
                          className={`border-b border-border/50 cursor-pointer transition-colors ${selectedRow.country === row.country ? "bg-primary/10" : "hover:bg-white/5"}`}
                        >
                          <td className="py-3 pr-4">
                            <div className="flex items-center gap-2">
                              <span className="text-base">{row.flag}</span>
                              <span className={row.isBest ? "text-green-400 font-medium" : "text-muted-foreground"}>{row.country}</span>
                              {row.isBest && <span className="px-1.5 py-0.5 bg-green-500/20 text-green-400 text-xs rounded">Best</span>}
                            </div>
                          </td>
                          <td className="py-3 px-3 text-right text-muted-foreground">{row.duty}%</td>
                          <td className="py-3 px-3 text-right text-muted-foreground">{row.tax}%</td>
                          <td className="py-3 px-3 text-right text-muted-foreground">${row.shipping.toLocaleString()}</td>
                          <td className="py-3 px-3 text-right font-semibold text-foreground">${row.total.toLocaleString()}</td>
                          <td className="py-3 pl-3 text-center"><DemandBadge demand={row.demand} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-4">
                <div className="glass-card p-5">
                  <h2 className="text-base font-semibold text-foreground mb-4">Cost Breakdown — <span className="text-primary">{selectedRow.country}</span></h2>
                  <div className="space-y-2.5 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">Base Price</span><span className="text-foreground">${costBreakdown.basePrice.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Import Duty {costBreakdown.importDutyPct}%</span><span className="text-orange-400">${costBreakdown.importDuty.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Customs {costBreakdown.customsChargesPct}%</span><span className="text-yellow-400">${costBreakdown.customsCharges.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">GST/VAT {costBreakdown.gstVatPct}%</span><span className="text-purple-400">${costBreakdown.gstVat.toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Shipping Cost</span><span className="text-primary">${costBreakdown.shippingCost.toFixed(2)}</span></div>
                    <div className="border-t border-border pt-2.5 mt-1 flex justify-between">
                      <span className="text-foreground font-semibold">Total Landed Cost</span>
                      <span className="text-green-400 font-bold text-base">${costBreakdown.total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Charts */}
            <div className="glass-card p-6">
              <h2 className="text-sm font-semibold text-muted-foreground tracking-widest uppercase mb-5">Price & Demand Trends — {searchQuery}</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-xs text-muted-foreground mb-3 uppercase tracking-wider">Price Trend (USD)</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <LineChart data={PRICE_TREND_DATA} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="month" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} domain={["auto", "auto"]} />
                      <Tooltip contentStyle={{ background: "hsl(225, 25%, 8%)", border: "1px solid hsla(230, 80%, 60%, 0.3)", borderRadius: "8px", color: "#e2e8f0" }} />
                      <Line type="monotone" dataKey="price" stroke="#06b6d4" strokeWidth={2} dot={{ fill: "#06b6d4", r: 3 }} activeDot={{ r: 5 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div>
                  <h3 className="text-xs text-muted-foreground mb-3 uppercase tracking-wider">Demand Index</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={DEMAND_INDEX_DATA} margin={{ top: 5, right: 5, bottom: 0, left: -20 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="month" tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: "#64748b", fontSize: 11 }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ background: "hsl(225, 25%, 8%)", border: "1px solid hsla(230, 80%, 60%, 0.3)", borderRadius: "8px", color: "#e2e8f0" }} />
                      <Bar dataKey="demand" fill="#0891b2" radius={[3, 3, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* AI Insights & Shipping */}
            <div className="grid lg:grid-cols-2 gap-6">
              <div className="glass-card p-5">
                <h2 className="text-base font-semibold text-foreground mb-4">AI-Powered Insights</h2>
                <div className="space-y-3">
                  {[
                    { icon: "✅", title: "AI Recommendation", color: "green", text: `Based on current tariffs and shipping costs, importing ${searchQuery} from UAE offers the lowest total landed cost with competitive delivery times.` },
                    { icon: "📊", title: "Demand Prediction", color: "cyan", text: `Market demand for ${searchQuery} is projected to remain strong over the next quarter. Consider increasing inventory levels.` },
                    { icon: "⏰", title: "Best Time to Import", color: "orange", text: "Historical data suggests Q1 and Q3 typically offer 8–12% lower shipping rates due to reduced seasonal demand on major trade routes." },
                    { icon: "⚠️", title: "Price Alert", color: "red", text: `${searchQuery} prices have fluctuated ±15% in the past 6 months. Setting up price alerts could save 5–10% on bulk orders.` },
                  ].map((insight) => (
                    <div key={insight.title} className={`flex gap-3 p-3 rounded-lg bg-${insight.color}-500/5 border border-${insight.color}-500/15`}>
                      <span className="text-xl mt-0.5">{insight.icon}</span>
                      <div>
                        <div className={`text-xs font-semibold text-${insight.color}-400 mb-1`}>{insight.title}</div>
                        <p className="text-xs text-muted-foreground leading-relaxed">{insight.text}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="glass-card p-5">
                <h2 className="text-base font-semibold text-foreground mb-4">Shipping & Logistics</h2>
                <div className="grid grid-cols-2 gap-4 mb-5">
                  <div className="p-3 rounded-lg bg-white/5">
                    <div className="text-xs text-muted-foreground mb-1">Est. Delivery</div>
                    <div className="text-xl font-bold text-purple-400">18 days</div>
                  </div>
                  <div className="p-3 rounded-lg bg-white/5">
                    <div className="text-xs text-muted-foreground mb-1">Shipping Cost</div>
                    <div className="text-xl font-bold text-primary">${selectedRow.shipping.toLocaleString()}</div>
                  </div>
                </div>
                <div className="text-xs text-muted-foreground uppercase tracking-wider mb-3">Top Carriers</div>
                <div className="space-y-2.5">
                  {SHIPPING_CARRIERS.map((carrier) => (
                    <div key={carrier.name} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 border border-primary/20 flex items-center justify-center text-xs font-bold text-primary">{carrier.name[0]}</div>
                        <span className="text-sm text-muted-foreground">{carrier.name}</span>
                      </div>
                      <StarRating rating={carrier.rating} />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

export default AnalysisPage;
