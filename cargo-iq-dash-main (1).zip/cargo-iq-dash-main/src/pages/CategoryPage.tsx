import { useParams, useNavigate } from "react-router-dom";
import { CATEGORIES, MOCK_PRODUCTS } from "@/data/mockData";

const CategoryPage = () => {
  const { slug } = useParams<{ slug?: string }>();
  const navigate = useNavigate();

  if (!slug) {
    return (
      <div className="min-h-screen pt-24 pb-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-10">
            <h1 className="text-3xl font-black text-foreground mb-2">Product <span className="neon-text">Categories</span></h1>
            <p className="text-muted-foreground">Explore global pricing across all major industries</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {CATEGORIES.map((cat) => {
              const products = MOCK_PRODUCTS.filter((p) => p.category === cat.name);
              return (
                <button key={cat.slug} onClick={() => navigate(`/categories/${cat.slug}`)}
                  className="glass-card p-6 text-left group transition-all duration-300 hover:scale-[1.02]"
                >
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-4xl group-hover:scale-110 transition-transform">{cat.icon}</span>
                    <div>
                      <h3 className="font-bold text-foreground group-hover:text-primary transition-colors">{cat.name}</h3>
                      <p className="text-xs text-muted-foreground mt-0.5">{cat.desc}</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{products.length} products tracked</span>
                    <span className="text-primary">Explore →</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  const category = CATEGORIES.find((c) => c.slug === slug);
  const products = MOCK_PRODUCTS.filter((p) => category ? p.category === category.name : true);

  if (!category) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center text-muted-foreground">
        <div className="text-center">
          <div className="text-5xl mb-4">🔍</div>
          <p>Category not found.</p>
          <button onClick={() => navigate("/categories")} className="mt-4 text-primary hover:underline">Browse all categories</button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="glass-card neon-border p-8 mb-8" style={{ background: "linear-gradient(135deg, hsla(var(--primary), 0.05), hsla(var(--secondary), 0.05))" }}>
          <div className="flex items-center gap-5">
            <span className="text-6xl">{category.icon}</span>
            <div>
              <button onClick={() => navigate("/categories")} className="text-xs text-muted-foreground hover:text-primary transition-colors mb-1">← All Categories</button>
              <h1 className="text-3xl font-black neon-text">{category.name}</h1>
              <p className="text-muted-foreground mt-1">{category.desc}</p>
              <div className="flex gap-3 mt-3">
                <span className="text-xs bg-primary/20 text-primary px-3 py-1 rounded-full">{products.length} Products</span>
                <span className="text-xs bg-secondary/20 text-secondary px-3 py-1 rounded-full">Global Pricing</span>
              </div>
            </div>
          </div>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground"><div className="text-5xl mb-4">📊</div><p>No products tracked for this category yet.</p></div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {products.map((product) => {
              const minUSD = Math.min(...product.countryPrices.map((cp) => cp.usdPrice));
              const maxUSD = Math.max(...product.countryPrices.map((cp) => cp.usdPrice));
              const cheapest = product.countryPrices.find((cp) => cp.usdPrice === minUSD);
              const savings = Math.round(((maxUSD - minUSD) / maxUSD) * 100);
              return (
                <button key={product.id} onClick={() => navigate("/products")}
                  className="glass-card p-5 text-left group transition-all duration-300 hover:scale-[1.02]"
                >
                  <div className="mb-3">
                    <h3 className="font-bold text-foreground group-hover:text-primary transition-colors">{product.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{product.brand}</p>
                    <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{product.specifications}</p>
                  </div>
                  <div className="flex flex-wrap gap-1 mb-4">
                    {product.countryPrices.slice(0, 5).map((cp) => (<span key={cp.country} className="text-sm">{cp.flag}</span>))}
                    {product.countryPrices.length > 5 && <span className="text-xs text-muted-foreground">+{product.countryPrices.length - 5} more</span>}
                  </div>
                  <div className="pt-3 border-t border-border/50 grid grid-cols-3 gap-2 text-center">
                    <div><div className="text-xs text-muted-foreground">Best Price</div><div className="text-sm font-bold text-green-400">${minUSD.toLocaleString()}</div></div>
                    <div><div className="text-xs text-muted-foreground">In</div><div className="text-sm">{cheapest?.flag} {cheapest?.country}</div></div>
                    <div><div className="text-xs text-muted-foreground">Save up to</div><div className="text-sm font-bold text-yellow-400">{savings}%</div></div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;
