import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Search } from "lucide-react";
import { CATEGORIES, MOCK_PRODUCTS, MOCK_LISTINGS } from "@/data/mockData";
import HeroSection from "@/components/HeroSection";
import ProblemSection from "@/components/ProblemSection";
import SolutionSection from "@/components/SolutionSection";
import FeaturesSection from "@/components/FeaturesSection";
import BenefitsSection from "@/components/BenefitsSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import VisionSection from "@/components/VisionSection";

const Index = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const handleSearch = (q: string) => {
    setSearchQuery(q);
    if (q.length > 1) {
      const matches = MOCK_PRODUCTS
        .filter((p) => p.name.toLowerCase().includes(q.toLowerCase()) || p.brand.toLowerCase().includes(q.toLowerCase()) || p.category.toLowerCase().includes(q.toLowerCase()))
        .map((p) => p.name)
        .slice(0, 6);
      setSuggestions(matches);
      setShowSuggestions(true);
    } else {
      setShowSuggestions(false);
    }
  };

  const stats = [
    { label: "Countries", value: "180+", icon: "🌐" },
    { label: "Products Listed", value: "50K+", icon: "📦" },
    { label: "Active Traders", value: "12K+", icon: "👥" },
    { label: "Avg. Savings", value: "23%", icon: "💰" },
  ];

  return (
    <div className="min-h-screen">
      {/* Marketplace Hero */}
      <section className="relative pt-32 pb-24 px-4 text-center overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-1/4 w-96 h-96 rounded-full opacity-10" style={{ background: "radial-gradient(circle, hsl(var(--primary)), transparent)", filter: "blur(60px)" }} />
          <div className="absolute top-40 right-1/4 w-96 h-96 rounded-full opacity-10" style={{ background: "radial-gradient(circle, hsl(var(--secondary)), transparent)", filter: "blur(60px)" }} />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-xs font-medium text-primary border border-primary/30 bg-primary/5 mb-8"
          >
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            Live Price Data from 180+ Countries
          </motion.div>

          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl sm:text-6xl md:text-7xl font-black leading-tight mb-6"
          >
            <span className="neon-text">Trade Globally.</span>
            <br />
            <span className="text-foreground">Buy </span>
            <span className="neon-text">Smarter.</span>
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10"
          >
            Compare product prices across 180+ countries, calculate exact import costs, and connect with verified global traders — all in one platform.
          </motion.p>

          {/* Search Bar */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}
            className="relative max-w-2xl mx-auto"
          >
            <div className="flex items-center glass-card neon-border p-2 gap-2">
              <div className="flex-1 flex items-center gap-3 px-3">
                <Search className="w-5 h-5 text-primary flex-shrink-0" />
                <input type="text" value={searchQuery}
                  onChange={(e) => handleSearch(e.target.value)}
                  onFocus={() => searchQuery.length > 1 && setShowSuggestions(true)}
                  placeholder="Search products, brands, categories..."
                  className="flex-1 bg-transparent outline-none text-foreground placeholder-muted-foreground text-base"
                  onKeyDown={(e) => e.key === "Enter" && navigate("/products")}
                />
              </div>
              <button onClick={() => navigate("/products")} className="glow-btn px-6 py-3 rounded-xl text-sm font-semibold text-white whitespace-nowrap">Search</button>
            </div>

            {showSuggestions && suggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 glass-card border border-border overflow-hidden z-50">
                {suggestions.map((s) => (
                  <button key={s} onClick={() => { setSearchQuery(s); setShowSuggestions(false); navigate("/products"); }}
                    className="block w-full text-left px-5 py-3 text-sm text-muted-foreground hover:bg-white/5 hover:text-primary transition-colors border-b border-border/50 last:border-0"
                  >
                    <span className="text-primary mr-2">🔍</span>{s}
                  </button>
                ))}
              </div>
            )}
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-3 mt-6"
          >
            {["Tesla Model 3", "iPhone 15 Pro", "Rolex Watch", "Solar Panels"].map((q) => (
              <button key={q} onClick={() => { setSearchQuery(q); navigate("/products"); }}
                className="px-3 py-1.5 text-xs text-muted-foreground border border-border rounded-full hover:border-primary/40 hover:text-primary transition-all"
              >{q}</button>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Stats */}
      <section className="max-w-5xl mx-auto px-4 mb-24">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {stats.map((stat) => (
            <div key={stat.label} className="glass-card p-6 text-center">
              <div className="text-3xl mb-2">{stat.icon}</div>
              <div className="text-2xl font-black neon-text">{stat.value}</div>
              <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 mb-24">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-foreground mb-2">Browse by Category</h2>
          <p className="text-muted-foreground">Explore global prices across all major product industries</p>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-9 gap-3">
          {CATEGORIES.map((cat, i) => (
            <button key={cat.slug} onClick={() => navigate(`/categories/${cat.slug}`)}
              className="glass-card p-4 text-center group cursor-pointer transition-all duration-300 hover:scale-105"
            >
              <div className="text-3xl mb-2 group-hover:scale-110 transition-transform">{cat.icon}</div>
              <div className="text-xs font-medium text-muted-foreground group-hover:text-primary transition-colors leading-tight">{cat.name}</div>
            </button>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4 mb-24">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-1">Featured Comparisons</h2>
            <p className="text-muted-foreground text-sm">Most searched products today</p>
          </div>
          <button onClick={() => navigate("/products")} className="text-primary text-sm hover:text-primary/80 border border-primary/30 px-4 py-2 rounded-lg hover:bg-primary/10 transition-all">View All →</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {MOCK_PRODUCTS.slice(0, 6).map((product) => {
            const minPrice = Math.min(...product.countryPrices.map((cp) => cp.usdPrice));
            const maxPrice = Math.max(...product.countryPrices.map((cp) => cp.usdPrice));
            const cheapest = product.countryPrices.find((cp) => cp.usdPrice === minPrice);
            return (
              <button key={product.id} onClick={() => navigate("/products")}
                className="glass-card p-5 text-left group transition-all duration-300 hover:scale-[1.02]"
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <span className="text-xs text-primary font-medium">{product.category}</span>
                    <h3 className="font-semibold text-foreground mt-1 group-hover:text-primary transition-colors">{product.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{product.brand}</p>
                  </div>
                  <span className="text-2xl">{CATEGORIES.find((c) => c.name === product.category)?.icon ?? "📦"}</span>
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50">
                  <div>
                    <div className="text-xs text-muted-foreground">Cheapest: {cheapest?.flag} {cheapest?.country}</div>
                    <div className="text-lg font-bold text-green-400">${minPrice.toLocaleString()}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">{product.countryPrices.length} countries</div>
                    <div className="text-xs text-muted-foreground">up to ${maxPrice.toLocaleString()}</div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Marketplace Preview */}
      <section className="max-w-7xl mx-auto px-4 mb-24">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-1">Live Marketplace</h2>
            <p className="text-muted-foreground text-sm">Connect with verified global traders</p>
          </div>
          <button onClick={() => navigate("/marketplace")} className="text-secondary text-sm hover:text-secondary/80 border border-secondary/30 px-4 py-2 rounded-lg hover:bg-secondary/10 transition-all">Explore →</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {MOCK_LISTINGS.filter((l) => l.isFeatured || l.isNew).slice(0, 4).map((listing) => (
            <button key={listing.id} className="glass-card p-4 group transition-all duration-300 hover:scale-[1.02] cursor-pointer text-left"
              onClick={() => navigate("/marketplace")}
            >
              <div className="flex items-center gap-2 mb-3">
                <span className="text-2xl">{listing.flag}</span>
                <div>
                  <div className="text-xs text-muted-foreground">{listing.country}</div>
                  {listing.isFeatured && <span className="text-xs text-yellow-400 font-medium">Featured</span>}
                  {listing.isNew && <span className="text-xs text-green-400 font-medium">New</span>}
                </div>
              </div>
              <h4 className="font-medium text-foreground text-sm mb-1 group-hover:text-primary transition-colors line-clamp-2">{listing.productName}</h4>
              <div className="text-xs text-muted-foreground mb-3">{listing.sellerName}</div>
              <div className="flex items-center justify-between">
                <span className="text-primary font-bold">${listing.priceUSD.toLocaleString()}</span>
                <div className="flex items-center gap-1">
                  <span className="text-yellow-400 text-xs">★</span>
                  <span className="text-xs text-muted-foreground">{listing.rating}</span>
                </div>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* Original Sections */}
      <ProblemSection />
      <SolutionSection />
      <FeaturesSection />
      <BenefitsSection />
      <HowItWorksSection />
      <VisionSection />

      {/* CTA */}
      <section className="max-w-4xl mx-auto px-4 mb-24 text-center">
        <div className="glass-card neon-border p-12">
          <h2 className="text-4xl font-black neon-text mb-4">Ready to Trade Globally?</h2>
          <p className="text-muted-foreground mb-8">Join 12,000+ traders saving up to 40% on international purchases</p>
          <div className="flex flex-wrap justify-center gap-4">
            <button onClick={() => navigate("/marketplace")} className="glow-btn px-8 py-4 rounded-xl font-semibold text-white">Start Trading</button>
            <button onClick={() => navigate("/calculator")} className="px-8 py-4 rounded-xl font-semibold text-muted-foreground border border-border hover:border-primary/40 hover:text-primary transition-all">Calculate Import Cost</button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
