import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { CATEGORIES, CURRENCIES, MOCK_PRODUCTS, convertPrice, formatPrice } from "@/data/mockData";

const ProductsPage = () => {
  const navigate = useNavigate();
  const [selectedProduct, setSelectedProduct] = useState(MOCK_PRODUCTS[0]);
  const [selectedCurrency, setSelectedCurrency] = useState("INR");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filtered = MOCK_PRODUCTS.filter((p) => {
    const matchesSearch = searchQuery === "" || p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const pricesInCurrency = selectedProduct.countryPrices.map((cp) => ({
    ...cp,
    converted: convertPrice(cp.usdPrice, selectedCurrency),
  }));

  const minConverted = Math.min(...pricesInCurrency.map((p) => p.converted));
  const maxConverted = Math.max(...pricesInCurrency.map((p) => p.converted));
  const categoryOptions = ["All", ...CATEGORIES.map((c) => c.name)];

  return (
    <div className="min-h-screen pt-24 pb-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-black text-foreground mb-2">
            Global <span className="neon-text">Price Dashboard</span>
          </h1>
          <p className="text-muted-foreground">Compare product prices across countries in real-time</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Product Selector */}
          <div className="lg:col-span-1">
            <div className="glass-card p-4 mb-4">
              <input
                type="text" placeholder="Search products..." value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-white/5 border border-border rounded-lg px-4 py-2.5 text-sm text-foreground placeholder-muted-foreground outline-none focus:border-primary/50 mb-3"
              />
              <div className="flex flex-wrap gap-2">
                {categoryOptions.slice(0, 5).map((cat) => (
                  <button key={cat} onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 text-xs rounded-full border transition-all ${selectedCategory === cat ? "bg-primary/20 border-primary/50 text-primary" : "border-border text-muted-foreground hover:border-border/80"}`}
                  >
                    {cat === "All" ? "All" : cat.split(" ")[0]}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
              {filtered.map((product) => (
                <button key={product.id} onClick={() => setSelectedProduct(product)}
                  className={`w-full glass-card p-3 text-left transition-all duration-200 ${selectedProduct.id === product.id ? "border-primary/50 bg-primary/10" : ""}`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{CATEGORIES.find((c) => c.name === product.category)?.icon ?? "📦"}</span>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-foreground text-sm truncate">{product.name}</div>
                      <div className="text-xs text-muted-foreground">{product.brand} • {product.countryPrices.length} countries</div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Price Comparison */}
          <div className="lg:col-span-2">
            <div className="glass-card p-6 mb-6">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                <div>
                  <h2 className="text-xl font-bold text-foreground">{selectedProduct.name}</h2>
                  <p className="text-sm text-muted-foreground mt-1">{selectedProduct.brand} • {selectedProduct.category}</p>
                  <p className="text-xs text-muted-foreground mt-1 max-w-lg">{selectedProduct.specifications}</p>
                </div>
                <select value={selectedCurrency} onChange={(e) => setSelectedCurrency(e.target.value)}
                  className="bg-card border border-border text-foreground px-3 py-2 rounded-lg text-sm outline-none focus:border-primary/50"
                >
                  {Object.entries(CURRENCIES).map(([code, info]) => (
                    <option key={code} value={code}>{code} ({info.symbol}) - {info.name}</option>
                  ))}
                </select>
              </div>

              {/* Price Cards */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
                {pricesInCurrency.map((cp) => {
                  const isCheapest = cp.converted === minConverted;
                  const isMostExpensive = cp.converted === maxConverted;
                  return (
                    <div key={cp.country}
                      className={`p-4 rounded-xl border transition-all ${isCheapest ? "bg-green-500/10 border-green-500/40" : isMostExpensive ? "bg-red-500/10 border-red-500/40" : "bg-white/[0.03] border-border"}`}
                    >
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-2xl">{cp.flag}</span>
                        <div>
                          <div className="text-xs text-muted-foreground">{cp.country}</div>
                          {isCheapest && <span className="text-xs text-green-400 font-medium">Cheapest ✓</span>}
                          {isMostExpensive && <span className="text-xs text-red-400 font-medium">Most Expensive</span>}
                        </div>
                      </div>
                      <div className="text-sm font-bold text-foreground">{formatPrice(cp.converted, selectedCurrency)}</div>
                      <div className="text-xs text-muted-foreground">${cp.usdPrice.toLocaleString()} USD</div>
                    </div>
                  );
                })}
              </div>

              {/* Bar Chart */}
              <div className="mt-4">
                <h3 className="text-sm font-medium text-muted-foreground mb-3">Price Comparison Chart</h3>
                <div className="space-y-3">
                  {pricesInCurrency.sort((a, b) => a.converted - b.converted).map((cp) => {
                    const barWidth = (cp.converted / maxConverted) * 100;
                    const isCheapest = cp.converted === minConverted;
                    return (
                      <div key={cp.country} className="flex items-center gap-3">
                        <div className="w-24 text-xs text-muted-foreground text-right flex-shrink-0">{cp.flag} {cp.country}</div>
                        <div className="flex-1 bg-white/5 rounded-full h-7 overflow-hidden">
                          <div className="price-bar h-full flex items-center px-3 text-xs font-medium text-white"
                            style={{
                              width: `${barWidth}%`,
                              background: isCheapest ? "linear-gradient(90deg, #10b981, #06b6d4)" : "linear-gradient(90deg, hsl(var(--primary)), hsl(var(--secondary)))",
                              boxShadow: isCheapest ? "0 0 10px rgba(16,185,129,0.4)" : "0 0 10px hsla(var(--primary), 0.3)",
                            }}
                          >
                            {formatPrice(cp.converted, selectedCurrency)}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Summary */}
            <div className="grid grid-cols-3 gap-4">
              {[
                { label: "Best Deal", value: pricesInCurrency.find((p) => p.converted === minConverted)?.country ?? "", sub: formatPrice(minConverted, selectedCurrency), color: "text-green-400", icon: "🟢" },
                { label: "Price Difference", value: `${Math.round(((maxConverted - minConverted) / minConverted) * 100)}%`, sub: "potential savings", color: "text-yellow-400", icon: "📊" },
                { label: "Countries Tracked", value: `${pricesInCurrency.length}`, sub: "price points", color: "text-primary", icon: "🌍" },
              ].map((item) => (
                <div key={item.label} className="glass-card p-4 text-center">
                  <div className="text-2xl mb-1">{item.icon}</div>
                  <div className="text-xs text-muted-foreground mb-1">{item.label}</div>
                  <div className={`text-lg font-bold ${item.color}`}>{item.value}</div>
                  <div className="text-xs text-muted-foreground">{item.sub}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;
