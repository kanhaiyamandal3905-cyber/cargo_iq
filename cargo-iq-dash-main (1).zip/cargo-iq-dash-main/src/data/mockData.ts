export interface MockProduct {
  id: number;
  name: string;
  category: string;
  brand: string;
  specifications: string;
  countryPrices: {
    country: string;
    flag: string;
    price: number;
    currency: string;
    usdPrice: number;
  }[];
}

export interface MockListing {
  id: number;
  productName: string;
  category: string;
  country: string;
  flag: string;
  priceUSD: number;
  sellerName: string;
  description: string;
  rating: number;
  reviews: number;
  isNew?: boolean;
  isFeatured?: boolean;
}

export const CURRENCIES: Record<string, { symbol: string; rate: number; name: string }> = {
  INR: { symbol: "₹", rate: 83.5, name: "Indian Rupee" },
  USD: { symbol: "$", rate: 1, name: "US Dollar" },
  EUR: { symbol: "€", rate: 0.93, name: "Euro" },
  GBP: { symbol: "£", rate: 0.79, name: "British Pound" },
  JPY: { symbol: "¥", rate: 149, name: "Japanese Yen" },
  AED: { symbol: "د.إ", rate: 3.67, name: "UAE Dirham" },
  SGD: { symbol: "S$", rate: 1.35, name: "Singapore Dollar" },
  CNY: { symbol: "¥", rate: 7.24, name: "Chinese Yuan" },
  KRW: { symbol: "₩", rate: 1340, name: "South Korean Won" },
};

export const COUNTRIES = [
  { name: "India", flag: "🇮🇳", currency: "INR" },
  { name: "USA", flag: "🇺🇸", currency: "USD" },
  { name: "Germany", flag: "🇩🇪", currency: "EUR" },
  { name: "Japan", flag: "🇯🇵", currency: "JPY" },
  { name: "China", flag: "🇨🇳", currency: "CNY" },
  { name: "UAE", flag: "🇦🇪", currency: "AED" },
  { name: "UK", flag: "🇬🇧", currency: "GBP" },
  { name: "Singapore", flag: "🇸🇬", currency: "SGD" },
  { name: "South Korea", flag: "🇰🇷", currency: "KRW" },
  { name: "Australia", flag: "🇦🇺", currency: "USD" },
  { name: "Canada", flag: "🇨🇦", currency: "USD" },
  { name: "France", flag: "🇫🇷", currency: "EUR" },
];

export const CATEGORIES = [
  { name: "Automobiles", icon: "🚗", slug: "automobiles", desc: "Cars, Bikes, EVs & Commercial Vehicles" },
  { name: "Electronics", icon: "📱", slug: "electronics", desc: "Mobiles, Laptops & Gaming Consoles" },
  { name: "Fashion & Luxury", icon: "👗", slug: "fashion", desc: "Clothing, Watches & Jewelry" },
  { name: "Home Appliances", icon: "🏠", slug: "home-appliances", desc: "Appliances & Furniture" },
  { name: "Cosmetics", icon: "💄", slug: "cosmetics", desc: "Beauty & Personal Care" },
  { name: "Industrial", icon: "🏭", slug: "industrial", desc: "Raw Materials & B2B" },
  { name: "Food & Agriculture", icon: "🌾", slug: "food", desc: "Food Products & Commodities" },
  { name: "Pharmaceuticals", icon: "💊", slug: "pharmaceuticals", desc: "Medical Devices & Medicines" },
  { name: "Energy & Tech", icon: "⚡", slug: "energy", desc: "Solar, Batteries & Semiconductors" },
];

export const MOCK_PRODUCTS: MockProduct[] = [
  {
    id: 1, name: "Tesla Model 3", category: "Automobiles", brand: "Tesla",
    specifications: "Long Range AWD, 0-60mph in 4.2s, 358 mile range, Autopilot",
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 40240, currency: "USD", usdPrice: 40240 },
      { country: "Germany", flag: "🇩🇪", price: 44990, currency: "EUR", usdPrice: 48376 },
      { country: "UK", flag: "🇬🇧", price: 42990, currency: "GBP", usdPrice: 54418 },
      { country: "China", flag: "🇨🇳", price: 279900, currency: "CNY", usdPrice: 38659 },
      { country: "Australia", flag: "🇦🇺", price: 62900, currency: "USD", usdPrice: 62900 },
      { country: "India", flag: "🇮🇳", price: 4030000, currency: "INR", usdPrice: 48263 },
    ],
  },
  {
    id: 2, name: "iPhone 15 Pro Max", category: "Electronics", brand: "Apple",
    specifications: "256GB, A17 Pro chip, 48MP camera, Titanium frame, iOS 17",
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 1199, currency: "USD", usdPrice: 1199 },
      { country: "India", flag: "🇮🇳", price: 159900, currency: "INR", usdPrice: 1915 },
      { country: "Japan", flag: "🇯🇵", price: 189800, currency: "JPY", usdPrice: 1273 },
      { country: "UAE", flag: "🇦🇪", price: 5199, currency: "AED", usdPrice: 1416 },
      { country: "Germany", flag: "🇩🇪", price: 1329, currency: "EUR", usdPrice: 1428 },
      { country: "Singapore", flag: "🇸🇬", price: 1749, currency: "SGD", usdPrice: 1296 },
      { country: "UK", flag: "🇬🇧", price: 1199, currency: "GBP", usdPrice: 1518 },
    ],
  },
  {
    id: 3, name: 'Samsung 65" QLED 4K TV', category: "Electronics", brand: "Samsung",
    specifications: '65" QLED, 4K 120Hz, Quantum HDR 32X, Gaming Hub, Neo QLED',
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 1297, currency: "USD", usdPrice: 1297 },
      { country: "India", flag: "🇮🇳", price: 139900, currency: "INR", usdPrice: 1675 },
      { country: "UK", flag: "🇬🇧", price: 1099, currency: "GBP", usdPrice: 1392 },
      { country: "Germany", flag: "🇩🇪", price: 1299, currency: "EUR", usdPrice: 1396 },
      { country: "South Korea", flag: "🇰🇷", price: 1590000, currency: "KRW", usdPrice: 1187 },
    ],
  },
  {
    id: 4, name: "Rolex Submariner", category: "Fashion & Luxury", brand: "Rolex",
    specifications: "41mm, Oystersteel, Ceramic bezel, 300m waterproof, Calibre 3235",
    countryPrices: [
      { country: "Switzerland", flag: "🇨🇭", price: 10800, currency: "USD", usdPrice: 10800 },
      { country: "UAE", flag: "🇦🇪", price: 42000, currency: "AED", usdPrice: 11444 },
      { country: "Singapore", flag: "🇸🇬", price: 16170, currency: "SGD", usdPrice: 11978 },
      { country: "India", flag: "🇮🇳", price: 1100000, currency: "INR", usdPrice: 13174 },
      { country: "UK", flag: "🇬🇧", price: 9300, currency: "GBP", usdPrice: 11772 },
      { country: "Japan", flag: "🇯🇵", price: 1460000, currency: "JPY", usdPrice: 9799 },
    ],
  },
  {
    id: 5, name: "Sony PlayStation 5", category: "Electronics", brand: "Sony",
    specifications: "Disc Edition, 825GB SSD, 4K 120Hz, DualSense controller",
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 499, currency: "USD", usdPrice: 499 },
      { country: "Japan", flag: "🇯🇵", price: 66980, currency: "JPY", usdPrice: 449 },
      { country: "UK", flag: "🇬🇧", price: 479, currency: "GBP", usdPrice: 607 },
      { country: "India", flag: "🇮🇳", price: 54990, currency: "INR", usdPrice: 659 },
      { country: "UAE", flag: "🇦🇪", price: 1999, currency: "AED", usdPrice: 545 },
      { country: "Germany", flag: "🇩🇪", price: 549, currency: "EUR", usdPrice: 590 },
    ],
  },
  {
    id: 6, name: "BMW M4 Competition", category: "Automobiles", brand: "BMW",
    specifications: "503 hp, 3.0L inline-6, xDrive AWD, 0-60 in 3.4s, Carbon fiber roof",
    countryPrices: [
      { country: "Germany", flag: "🇩🇪", price: 82900, currency: "EUR", usdPrice: 89108 },
      { country: "USA", flag: "🇺🇸", price: 76100, currency: "USD", usdPrice: 76100 },
      { country: "UK", flag: "🇬🇧", price: 72840, currency: "GBP", usdPrice: 92198 },
      { country: "India", flag: "🇮🇳", price: 13400000, currency: "INR", usdPrice: 160479 },
      { country: "UAE", flag: "🇦🇪", price: 295000, currency: "AED", usdPrice: 80381 },
    ],
  },
  {
    id: 7, name: 'MacBook Pro 16" M3', category: "Electronics", brand: "Apple",
    specifications: "M3 Max chip, 36GB RAM, 1TB SSD, Liquid Retina XDR, 22hr battery",
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 3499, currency: "USD", usdPrice: 3499 },
      { country: "UK", flag: "🇬🇧", price: 3499, currency: "GBP", usdPrice: 4428 },
      { country: "India", flag: "🇮🇳", price: 329900, currency: "INR", usdPrice: 3951 },
      { country: "Japan", flag: "🇯🇵", price: 548800, currency: "JPY", usdPrice: 3681 },
      { country: "Germany", flag: "🇩🇪", price: 3799, currency: "EUR", usdPrice: 4085 },
    ],
  },
  {
    id: 8, name: "Dyson V15 Detect", category: "Home Appliances", brand: "Dyson",
    specifications: "Cordless vacuum, 60 min runtime, Laser dust detection, HEPA filtration",
    countryPrices: [
      { country: "UK", flag: "🇬🇧", price: 649, currency: "GBP", usdPrice: 822 },
      { country: "USA", flag: "🇺🇸", price: 749, currency: "USD", usdPrice: 749 },
      { country: "Germany", flag: "🇩🇪", price: 749, currency: "EUR", usdPrice: 805 },
      { country: "India", flag: "🇮🇳", price: 72900, currency: "INR", usdPrice: 873 },
      { country: "Singapore", flag: "🇸🇬", price: 1099, currency: "SGD", usdPrice: 814 },
    ],
  },
  {
    id: 9, name: "Louis Vuitton Neverfull MM", category: "Fashion & Luxury", brand: "Louis Vuitton",
    specifications: "Monogram canvas, 31x28x14cm, Golden hardware, Zipped pouch included",
    countryPrices: [
      { country: "France", flag: "🇫🇷", price: 1540, currency: "EUR", usdPrice: 1656 },
      { country: "USA", flag: "🇺🇸", price: 1860, currency: "USD", usdPrice: 1860 },
      { country: "Japan", flag: "🇯🇵", price: 207900, currency: "JPY", usdPrice: 1395 },
      { country: "UAE", flag: "🇦🇪", price: 6600, currency: "AED", usdPrice: 1798 },
      { country: "India", flag: "🇮🇳", price: 195000, currency: "INR", usdPrice: 2335 },
    ],
  },
  {
    id: 10, name: "Panasonic Solar Panel 400W", category: "Energy & Tech", brand: "Panasonic",
    specifications: "HIT 400W, 21.7% efficiency, 25-year warranty, EverVolt series",
    countryPrices: [
      { country: "Japan", flag: "🇯🇵", price: 80000, currency: "JPY", usdPrice: 537 },
      { country: "USA", flag: "🇺🇸", price: 450, currency: "USD", usdPrice: 450 },
      { country: "Germany", flag: "🇩🇪", price: 380, currency: "EUR", usdPrice: 409 },
      { country: "India", flag: "🇮🇳", price: 22000, currency: "INR", usdPrice: 263 },
      { country: "China", flag: "🇨🇳", price: 1800, currency: "CNY", usdPrice: 249 },
    ],
  },
  {
    id: 11, name: "Pfizer Eliquis 5mg", category: "Pharmaceuticals", brand: "Pfizer",
    specifications: "60 tablets, Anticoagulant, Apixaban 5mg, FDA approved",
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 540, currency: "USD", usdPrice: 540 },
      { country: "Canada", flag: "🇨🇦", price: 180, currency: "USD", usdPrice: 180 },
      { country: "UK", flag: "🇬🇧", price: 78, currency: "GBP", usdPrice: 99 },
      { country: "India", flag: "🇮🇳", price: 3500, currency: "INR", usdPrice: 42 },
      { country: "Germany", flag: "🇩🇪", price: 85, currency: "EUR", usdPrice: 91 },
    ],
  },
  {
    id: 12, name: "Wheat (1 Metric Ton)", category: "Food & Agriculture", brand: "Commodity",
    specifications: "Hard Red Winter Wheat, Protein 12%+, Moisture <13.5%",
    countryPrices: [
      { country: "USA", flag: "🇺🇸", price: 220, currency: "USD", usdPrice: 220 },
      { country: "India", flag: "🇮🇳", price: 22000, currency: "INR", usdPrice: 263 },
      { country: "Germany", flag: "🇩🇪", price: 195, currency: "EUR", usdPrice: 210 },
      { country: "China", flag: "🇨🇳", price: 1800, currency: "CNY", usdPrice: 249 },
      { country: "Australia", flag: "🇦🇺", price: 310, currency: "USD", usdPrice: 310 },
    ],
  },
  {
    id: 13, name: "SK Hynix HBM3E Memory", category: "Energy & Tech", brand: "SK Hynix",
    specifications: "36GB, 1.2TB/s bandwidth, AI accelerator memory, DRAM",
    countryPrices: [
      { country: "South Korea", flag: "🇰🇷", price: 4000000, currency: "KRW", usdPrice: 2985 },
      { country: "USA", flag: "🇺🇸", price: 3200, currency: "USD", usdPrice: 3200 },
      { country: "Japan", flag: "🇯🇵", price: 480000, currency: "JPY", usdPrice: 3221 },
      { country: "Singapore", flag: "🇸🇬", price: 4350, currency: "SGD", usdPrice: 3222 },
    ],
  },
  {
    id: 14, name: "L'Oreal Revitalift Serum", category: "Cosmetics", brand: "L'Oreal",
    specifications: "30ml, 1.5% Pure Hyaluronic Acid, 3.5% Vitamin C, Anti-aging",
    countryPrices: [
      { country: "France", flag: "🇫🇷", price: 35, currency: "EUR", usdPrice: 38 },
      { country: "USA", flag: "🇺🇸", price: 42, currency: "USD", usdPrice: 42 },
      { country: "India", flag: "🇮🇳", price: 2200, currency: "INR", usdPrice: 26 },
      { country: "UK", flag: "🇬🇧", price: 28, currency: "GBP", usdPrice: 35 },
      { country: "UAE", flag: "🇦🇪", price: 155, currency: "AED", usdPrice: 42 },
    ],
  },
  {
    id: 15, name: "TSMC 3nm Chip Wafer", category: "Industrial", brand: "TSMC",
    specifications: "300mm silicon wafer, 3nm process node, N3E generation",
    countryPrices: [
      { country: "Taiwan", flag: "🇹🇼", price: 20000, currency: "USD", usdPrice: 20000 },
      { country: "USA", flag: "🇺🇸", price: 25000, currency: "USD", usdPrice: 25000 },
      { country: "Japan", flag: "🇯🇵", price: 3500000, currency: "JPY", usdPrice: 23490 },
      { country: "South Korea", flag: "🇰🇷", price: 27000000, currency: "KRW", usdPrice: 20149 },
    ],
  },
];

export const MOCK_LISTINGS: MockListing[] = [
  { id: 1, productName: "Tesla Model 3 Long Range", category: "Automobiles", country: "USA", flag: "🇺🇸", priceUSD: 38000, sellerName: "AutoTrade Inc.", description: "Brand new Tesla Model 3 LR with full self-driving capability. Factory warranty included.", rating: 4.8, reviews: 124, isFeatured: true },
  { id: 2, productName: "iPhone 15 Pro Max 512GB", category: "Electronics", country: "Japan", flag: "🇯🇵", priceUSD: 1150, sellerName: "TokyoTech Exports", description: "Sealed box iPhone 15 Pro Max. Japanese version, all bands compatible globally.", rating: 4.9, reviews: 89, isNew: true },
  { id: 3, productName: "Rolex GMT Master II", category: "Fashion & Luxury", country: "Switzerland", flag: "🇨🇭", priceUSD: 12500, sellerName: "Swiss Luxury Hub", description: "Authorized dealer stock. Comes with full certificate and box.", rating: 5.0, reviews: 34 },
  { id: 4, productName: "BMW M4 Competition 2024", category: "Automobiles", country: "Germany", flag: "🇩🇪", priceUSD: 78000, sellerName: "EuroMotors GmbH", description: "Direct factory order. Carbon fiber package, M Sport seats. EU specs.", rating: 4.7, reviews: 56, isFeatured: true },
  { id: 5, productName: "Sony PS5 Slim Bundle", category: "Electronics", country: "Japan", flag: "🇯🇵", priceUSD: 480, sellerName: "GameZone JP", description: "PS5 Slim with 2 controllers and Spider-Man 2. Japanese region free.", rating: 4.6, reviews: 210 },
  { id: 6, productName: "MacBook Pro M3 Max", category: "Electronics", country: "USA", flag: "🇺🇸", priceUSD: 3299, sellerName: "AppleCert Reseller", description: "Open box, like new. Space Black, 36GB RAM, 1TB SSD.", rating: 4.9, reviews: 67, isNew: true },
  { id: 7, productName: "Dyson Airwrap Multi-styler", category: "Home Appliances", country: "UK", flag: "🇬🇧", priceUSD: 590, sellerName: "UK Beauty Exports", description: "Complete edition with 8 attachments. Global voltage. Full warranty.", rating: 4.7, reviews: 145 },
  { id: 8, productName: "Wheat Grade A (50 MT)", category: "Food & Agriculture", country: "India", flag: "🇮🇳", priceUSD: 11500, sellerName: "AgroTrade India", description: "Premium Hard Red Wheat, 50 metric tons. FOB Mumbai. Certificate of origin included.", rating: 4.5, reviews: 28 },
  { id: 9, productName: "Solar Panel 540W Mono", category: "Energy & Tech", country: "China", flag: "🇨🇳", priceUSD: 180, sellerName: "SolarMax China", description: "Monocrystalline 540W panel, 21.5% efficiency, 30yr warranty. Min order 100 pcs.", rating: 4.4, reviews: 92, isFeatured: true },
  { id: 10, productName: "L'Oreal Pro Skincare Set", category: "Cosmetics", country: "France", flag: "🇫🇷", priceUSD: 210, sellerName: "Paris Beauty Co.", description: "Complete anti-aging routine set, 6 products. Official L'Oreal distribution.", rating: 4.6, reviews: 178 },
];

export const TAX_RULES: Record<string, { duty: number; gst: number; insurance: number; handling: number }> = {
  Automobiles: { duty: 1.0, gst: 0.28, insurance: 0.02, handling: 500 },
  Electronics: { duty: 0.2, gst: 0.18, insurance: 0.01, handling: 100 },
  "Fashion & Luxury": { duty: 0.35, gst: 0.18, insurance: 0.015, handling: 200 },
  "Home Appliances": { duty: 0.25, gst: 0.18, insurance: 0.01, handling: 150 },
  Cosmetics: { duty: 0.2, gst: 0.12, insurance: 0.005, handling: 80 },
  Industrial: { duty: 0.15, gst: 0.12, insurance: 0.01, handling: 300 },
  "Food & Agriculture": { duty: 0.3, gst: 0.05, insurance: 0.005, handling: 50 },
  Pharmaceuticals: { duty: 0.1, gst: 0.12, insurance: 0.01, handling: 150 },
  "Energy & Tech": { duty: 0.1, gst: 0.12, insurance: 0.008, handling: 120 },
  default: { duty: 0.25, gst: 0.18, insurance: 0.01, handling: 200 },
};

export function convertPrice(usdPrice: number, currency: string): number {
  const rate = CURRENCIES[currency]?.rate ?? 1;
  return usdPrice * rate;
}

export function formatPrice(amount: number, currency: string): string {
  const sym = CURRENCIES[currency]?.symbol ?? "$";
  if (amount >= 1000000) return `${sym}${(amount / 1000000).toFixed(2)}M`;
  if (amount >= 1000) return `${sym}${(amount / 1000).toFixed(1)}K`;
  return `${sym}${amount.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}
