export interface CountryComparison {
  country: string;
  flag: string;
  duty: number;
  tax: number;
  shipping: number;
  total: number;
  demand: "High" | "Medium" | "Low";
  isBest?: boolean;
}

export interface PriceTrendPoint { month: string; price: number; }
export interface DemandPoint { month: string; demand: number; }
export interface Carrier { name: string; rating: number; }

export const LITHIUM_BATTERY_COMPARISONS: CountryComparison[] = [
  { country: "UAE", flag: "🇦🇪", duty: 5, tax: 5, shipping: 958, total: 2348, demand: "Medium", isBest: true },
  { country: "Japan", flag: "🇯🇵", duty: 5, tax: 18, shipping: 1160, total: 2538, demand: "Medium" },
  { country: "South Korea", flag: "🇰🇷", duty: 8, tax: 18, shipping: 1050, total: 2563, demand: "High" },
  { country: "India", flag: "🇮🇳", duty: 18, tax: 18, shipping: 969, total: 2647, demand: "High" },
  { country: "United States", flag: "🇺🇸", duty: 5, tax: 8, shipping: 1560, total: 2838, demand: "High" },
  { country: "Germany", flag: "🇩🇪", duty: 4.5, tax: 19, shipping: 1508, total: 3177, demand: "Medium" },
  { country: "China", flag: "🇨🇳", duty: 7.5, tax: 13, shipping: 1288, total: 3754, demand: "High" },
  { country: "Brazil", flag: "🇧🇷", duty: 14, tax: 17, shipping: 2269, total: 3926, demand: "Low" },
];

export const PRICE_TREND_DATA: PriceTrendPoint[] = [
  { month: "Jan", price: 1180 }, { month: "Feb", price: 1210 }, { month: "Mar", price: 1195 },
  { month: "Apr", price: 1240 }, { month: "May", price: 1280 }, { month: "Jun", price: 1260 },
  { month: "Jul", price: 1300 }, { month: "Aug", price: 1290 }, { month: "Sep", price: 1320 },
  { month: "Oct", price: 1310 }, { month: "Nov", price: 1340 }, { month: "Dec", price: 1250 },
];

export const DEMAND_INDEX_DATA: DemandPoint[] = [
  { month: "Jan", demand: 62 }, { month: "Feb", demand: 68 }, { month: "Mar", demand: 71 },
  { month: "Apr", demand: 75 }, { month: "May", demand: 80 }, { month: "Jun", demand: 77 },
  { month: "Jul", demand: 85 }, { month: "Aug", demand: 88 }, { month: "Sep", demand: 92 },
  { month: "Oct", demand: 87 }, { month: "Nov", demand: 90 }, { month: "Dec", demand: 83 },
];

export const SHIPPING_CARRIERS: Carrier[] = [
  { name: "Maersk Line", rating: 4.8 },
  { name: "MSC", rating: 4.8 },
  { name: "CMA CGM", rating: 4.5 },
  { name: "COSCO Shipping", rating: 4.3 },
];

export interface CostBreakdown {
  country: string; basePrice: number;
  importDutyPct: number; importDuty: number;
  customsChargesPct: number; customsCharges: number;
  gstVatPct: number; gstVat: number;
  shippingCost: number; total: number;
}

export const COST_BREAKDOWNS: Record<string, CostBreakdown> = {
  China: { country: "China", basePrice: 1256.88, importDutyPct: 25, importDuty: 392.75, customsChargesPct: 2.5, customsCharges: 321.25, gstVatPct: 13, gstVat: 178.7, shippingCost: 1366.08, total: 2753.75 },
  UAE: { country: "UAE", basePrice: 1256.88, importDutyPct: 5, importDuty: 62.84, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 5, gstVat: 67.56, shippingCost: 958.0, total: 2376.7 },
  Japan: { country: "Japan", basePrice: 1256.88, importDutyPct: 5, importDuty: 62.84, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 18, gstVat: 243.42, shippingCost: 1160.0, total: 2754.56 },
  "South Korea": { country: "South Korea", basePrice: 1256.88, importDutyPct: 8, importDuty: 100.55, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 18, gstVat: 243.42, shippingCost: 1050.0, total: 2682.27 },
  India: { country: "India", basePrice: 1256.88, importDutyPct: 18, importDuty: 226.24, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 18, gstVat: 267.57, shippingCost: 969.0, total: 2751.11 },
  "United States": { country: "United States", basePrice: 1256.88, importDutyPct: 5, importDuty: 62.84, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 8, gstVat: 107.3, shippingCost: 1560.0, total: 3018.44 },
  Germany: { country: "Germany", basePrice: 1256.88, importDutyPct: 4.5, importDuty: 56.56, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 19, gstVat: 256.5, shippingCost: 1508.0, total: 3109.36 },
  Brazil: { country: "Brazil", basePrice: 1256.88, importDutyPct: 14, importDuty: 175.96, customsChargesPct: 2.5, customsCharges: 31.42, gstVatPct: 17, gstVat: 247.15, shippingCost: 2269.0, total: 3980.41 },
};
